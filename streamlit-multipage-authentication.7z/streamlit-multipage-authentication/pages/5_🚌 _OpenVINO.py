import os
import time
import requests
import pandas as pd
import numpy as np

import streamlit as st
import folium
from streamlit_folium import st_folium
import aspose.slides as slides


st.set_page_config(page_title="streamlit-folium documentation",page_icon="📈")


# st.header("Open VINO")
"# 📈 Open VINO"